# Updated banners — C-US-RYT-IM-0390

Four separate packages: 160x600, 300x250, 300x600, 728x90. Open index.html inside each size folder. links.json beside each HTML lists its four destination URLs. preview.html links to and displays every size; refresh to restart animation.

## What changed

Used the supplied PDF as the content/design reference (the pages without AdChoices). The PDF's annotations were treated as reference notes, not independent instructions. Preserved the original export runtime, fixed-size outer shell, background image path, brand SVG path, font reference and safety-panel structure. Replaced the old campaign's frame layers/copy and embedded safety copy with the new campaign. Size-specific layout and safety-panel positioning follow the new PDF. Originals are untouched.

Timeline: frame 1 0–3s; frame 2 3–7s; frame 3 7–12s; frame 4 12–15s and then stays visible. Safety panel enters at 3s, CTA at 7s. The full ISI auto-scroll starts at 15s and takes 60 seconds when uninterrupted; hover, keyboard focus or dragging pauses it. Manual scrolling remains available after completion. Final frame stays visible, and the ISI stays at its end.

## Add your media

No media files were uploaded with the four HTML files. Place the original assets in each size's media/ folder, keeping the filenames listed in ASSETS.csv. Each banner currently needs its original background PNG and the shared RYTELO SVG, plus media/geron-logo.png for the Geron footer. The HTML includes meaningful alt text for logos. Missing art will show blank/broken-image areas until you add it. Fonts retain the original Google Fonts reference, with Arial as fallback.

New copy, percentages, orange headers, rules, VS badge, CTA, footnotes and NCCN recommendation are live HTML/CSS, so they do not require replacement text images. The NCCN framed mark is HTML text and CSS; you may replace .guideline-mark with approved NCCN artwork if required. The background and RYTELO/Geron logos use images. The ASSETS.csv rows marked Unused refer to original CSS assets no longer used by the updated frames; you do not need to supply them.

The original media itself was not attached, so its pixels and any text baked into those image files could not be inspected. In particular, do not assume that an unused original PNG/GIF contains current approved copy. The updated treatment indication and primary-endpoint data are now HTML, avoiding dependence on those unknown original images.

## Checks

Browser checks verified all four frame sequences, full ISI content, final-frame retention, the complete 60-second automatic scroll and no JavaScript exceptions. Layout checks used the local fallback font because external font requests were blocked during testing. Missing artwork is expected. Final visual comparison with your supplied media and production font is still needed; this package is not a claim of pixel-exact artwork validation.

## Links

- Learn more: https://www.rytelohcp.com/
- Prescribing Information: https://pi.geron.com/products/US/pi/rytelo_pi.pdf
- Medication Guide: https://pi.geron.com/products/US/pi/rytelo_mg.pdf
- MedWatch: https://www.fda.gov/safety/medwatch-fda-safety-information-and-adverse-event-reporting-program

To change destinations, update the actual anchor href values in index.html (including the safety embedCode inside designData). links.json is a reference list; editing it alone does not update the banner.

## Script structure correction
The original single outer script tag and export engine are preserved. The designData object again uses the original JavaScript object-literal style, including a single-quoted embedCode string. Embedded HTML uses JavaScript hexadecimal escapes for opening angle brackets so nested script tags cannot end the outer script. Decoding yields normal HTML and script tags inside the safety panel. Folder names in this corrected package use uppercase X (for example 160X600), matching the reported localhost path.
